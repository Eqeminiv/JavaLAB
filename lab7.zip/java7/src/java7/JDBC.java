/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java7;
import java.sql.*;

/**
 *
 * @author Student_test
 */
public class JDBC {
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/osoby";
				String login = "root";
				String password = "";
				Connection conn = DriverManager.getConnection(url,login,password);
                                
                                Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("SELECT * FROM studenci");
                                //rs.next();
                                
                                //System.out.println(rs.getString("imie"));
                                
                                //while(rs.next())
                                //{
                               //     System.out.println(rs.getString("imie"));
                               // }
                              
                              
                                int colCount = rs.getMetaData().getColumnCount();
                                int counter = 1;
                                for(int i=1;i<=colCount;i++)
                                {
                                    System.out.print(rs.getMetaData().getColumnName(i)+"\t");
                                    
                                }
                                System.out.println();
                                while(rs.next())
                                {
                                    for(int i=1;i<=colCount;i++)
                                    {
                                        System.out.print(rs.getString(i)+"\t");
                                    }
                                    System.out.println();
                                           
                                    counter++;
                                }
                                
                                //st.execute("CREATE TABLE przedmioty(przedmiot VARCHAR(20),semestr INT)");
    }
    
}
